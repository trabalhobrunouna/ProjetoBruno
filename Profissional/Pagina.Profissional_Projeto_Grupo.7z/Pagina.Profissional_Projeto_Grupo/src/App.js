import React, { Component } from 'react';

import main from './main'

class App extends Component {
  render() {
    return (
      <div>
        <main />
      </div>
    );
  }
}

export default App;