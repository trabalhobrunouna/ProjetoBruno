import React, {useState, useEffect, Fragment} from 'react';
import { NavLink } from 'react-router-dom';

function Index2(){
    return(
<section>
<h5 class="ASO">ASO.com</h5>
  <h1 class="Titulo">Bem vindo, usuário</h1>
  <section class="grid-menu">
    <div class="perfil">
    <NavLink to="Perfil"> 
    <div>
      <button type="button" class="perfil">
        <img src="img/iconePessoa.svg" alt="ícone usuário"/>
        Perfil
      </button>
      </div>
    </NavLink>
    </div>
    <div class="agendado">
      <button type="button" class="agendado">
        <img src="img/relógio 1.svg" alt="ícone relógio"/>
        Solicitações de agendamento
      </button>
    </div>
    <div class="sair">
      <button type="button" class="sair">
        <img src="img/icone_sair.svg" alt="ícone porta"/>
        Sair
      </button>
    </div>
  </section>
  <section class="MenuquadradoBranco">
    <div class="ServiçosPrestados">
      <button type="button" class="botaoAdicionarServicos">
        Adicionar Serviços
      </button>
    </div>
    <div className="ServiçosCadastrados">
      Ainda não possui serviços cadastrados
    </div>
  </section>
  <div id="root"></div>
  </section>
  );
}
export default Index2;
