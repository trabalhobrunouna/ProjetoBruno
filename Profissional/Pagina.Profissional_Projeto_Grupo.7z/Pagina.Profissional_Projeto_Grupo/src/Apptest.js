import React, { useState, useEffect, Fragment } from 'react'
import UserTable from './tables/UserTable'
import AddUserForm from './forms/UserAddForm'
import EditUserForm from './forms/EditUserForm'

const App = () => {
  const baseUrl = "https://funcionarios2-api.herokuapp.com/empresas"
  const initialFormState = { servicos: '', insumos: '', portifolio: '', horarios: '' }
  const [users, setUsers] = useState([])
  const [currentUser, setCurrentUser] = useState(initialFormState)
  const [editing, setEditing] = useState(false)


  useEffect(() => {
    getUserService();
  }, []);

  //CRUD operações
  const addUser = user => {
    addUserService(user);
  }

  const deleteUser = servicos => {
    if (window.confirm("Você realmente deseja DELETAR?")) {
      setEditing(false)
      removeUserService(servicos);
    }
  }

  const updateUser = (servicos, updateUser) => {
    updateUserService(updateUser)
  }

  const editRow = user => {
    setEditing(true)
    setCurrentUser({ servicos: user.servicos, insumos: user.insumos, portifolio: user.portifolio, horarios: user.horarios })
  }

  return (
    <div className="container">
      <h1>CRUD App with Hooks</h1>
      <div className="flex-row">
        <div className="flex-large">
          {editing ? (
            <Fragment>
              <h2>Edit user</h2>
              <EditUserForm
                editing={editing}
                setEditing={setEditing}
                currentUser={currentUser}
                updateUser={updateUser}
              />
            </Fragment>
          ) : (
            <Fragment>
              <h2>Add user</h2>
              <AddUserForm addUser={addUser} />
            </Fragment>
          )}
        </div>
        <div className="flex-large">
          <h2>View users</h2>
          <UserTable users={users} editRow={editRow} deleteUser={deleteUser} />
        </div>
      </div>
    </div>
  );

  async function getUserService() {
    fetch(baseUrl)
      .then(response => response.json())
      .then(data => {
        setUsers(data);
      });
  }

  async function removeUserService(servicos) {
    fetch(baseUrl + servicos, {
      method: "DELETE"
    })
      .then(response => {
        getUserService();
      })
  }

  async function addUserService(user) {
    fetch(baseUrl, {
      headers: {
        'Accept': 'application/json',
        'Content-type': 'application/json'
      },
      method: "POST",
      body: JSON.stringify(user)
    })
      .then(
        reponse => {
          getUserService();
        }
      )
  }

  async function updateUserService(user) {
    fetch(baseUrl + user.servicos, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      method: "PUT",
      body: JSON.stringify(user)
    })
      .then(
        response => {
          setCurrentUser(user);
          getUserService()
        }
      )
  }
}

  export default App
