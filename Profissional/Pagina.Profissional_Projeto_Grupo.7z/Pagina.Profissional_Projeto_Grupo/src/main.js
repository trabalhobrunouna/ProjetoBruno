// Importantando o React
import React from "react";
// Importantando o component Home
import Index2 from "./index2";
// Importantando o component Contact
import Perfil from "./index2/Perfil";

// Importanto o component <Switch /> e <Route /> da nossa Lib de rotas
import { Switch, Route } from 'react-router-dom'

const main = () => (
    <main>
      <>
        <Switch>
          <Route exact path='/Perfil' component={Perfil}/>

        </Switch>
      </>
    </main>  
  );
export default main;